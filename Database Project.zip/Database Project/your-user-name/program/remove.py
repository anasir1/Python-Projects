import json
import os
from buildTree import traverse_all_node

def write_to_file(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file)

def read_from_file(file_path):
    file = open(file_path)
    return json.load(file)

def remove_tree(relation, attribute):
    directory = read_from_file("../index/directory.txt")
    root_page = ''
    for item in directory:
        if item[0] == relation and item[1] == attribute:
            root_page = item[2]
            directory.remove(item)
            write_to_file(directory, "../index/directory.txt")

    if root_page != '':
        all_items = traverse_all_node(root_page)
        seen_pages = set()
        new_list = []
        for obj in all_items:
            if obj['page'] not in seen_pages:
                new_list.append(obj)
                seen_pages.add(obj['page'])

        page_pool = read_from_file("../index/pagePool.txt")
        for item in new_list:
            os.remove("../index/" + item['page'])
            page_pool.append(item['page'])

        write_to_file(page_pool, "../index/pagePool.txt")
        # traverse all nodes and delete them
    return

def remove_table(relation):

    if os.path.isdir('../data/' + relation):
        page_link = read_from_file("../data/" + relation + "/pageLink.txt")

        # remove pages from relation and add in page pool
        page_pool = read_from_file("../data/pagePool.txt")
        for page_no in page_link:
            os.remove("../data/" + relation + "/" + page_no)
            page_pool.append(page_no)
            write_to_file(page_pool, "../data/pagePool.txt")

        # remove from schema
        schema = read_from_file("../data/schemas.txt")
        new_schema = list(schema)
        if schema:
            for item in schema:
                if item[0] == relation:
                    new_schema.remove(item)

            write_to_file(new_schema, "../data/schemas.txt")

        os.remove("../data/" + relation + "/pageLink.txt")
        os.rmdir("../data/" + relation)
    else:
        print('No such Table found as ' + relation)


# remove_tree("Supply", "pid")
# remove_tree("Suppliers", "sid")
