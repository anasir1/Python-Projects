import json
import os
from buildTree import find_in_tree, check_btree_on_rel_and_att
from remove import remove_table


def write_to_file(data, page):
    with open(page, 'w') as file:
        json.dump(data, file)


def read_from_file(path):
    try:
        with open(path) as file:
            return json.load(file)
    except:
        return


def find_location_of_attr_in_tuple(rel, att):
    schema = read_from_file("../data/schemas.txt")
    if schema:
        for item in schema:
            if item[0] == rel and item[1] == att:
                return item[3]


def find_in_btree(rel, att, val):
    leaf_node_return = find_in_tree(rel, att, val)
    leaf_node = leaf_node_return['page']
    if not leaf_node:
        return {'btree': False, 'cost': 0, 'leaf': ''}
    else:
        return {'btree': True, 'cost': leaf_node_return['cost'], 'leaf': leaf_node}


def read_page(rel, page):
    # Read the content of a page in relation rel
    with open(os.path.join('..', 'data', rel, page), 'r') as page_file:
        page_content = json.load(page_file)
    return page_content

def select(rel, att, op, val):
    # Select tuples from relation rel based on a condition
    # att <op> val
    rel_path = f'../data/{rel}/pageLink.txt'
    total_pages_read = -1

    # Check if the relation exists
    if os.path.exists(rel_path):
        # Read the page link file to get the sequence of pages
        with open(rel_path, 'r') as link_file:
            # Read the content of the file and clean up the string
            pages_str = link_file.read().strip('[]').replace('"', '')
        
            # Convert the cleaned string to a list
            pages = [page.strip() for page in pages_str.split(',')]

            # Now 'pages' should be a list of page names
            for page in pages:
                # Read the content of the current page
                page_content = read_page(rel, page)

                # Increment the total pages read count
                total_pages_read += 1

                # Placeholder for condition check
                # Assuming att is present in the first position of each tuple
                if op == '=' and any(str(entry[0]) == val for entry in page_content):
                    break
                elif op == '<' and any(str(entry[0]) < val for entry in page_content):
                    break
                elif op == '<=' and any(str(entry[0]) <= str(val) for entry in page_content):
                    break
                elif op == '>' and any(str(entry[0]) > val for entry in page_content):
                    break
                elif op == '>=' and any(str(entry[0]) >= str(val) for entry in page_content):

                    break

            if total_pages_read > 0:
                print(f"With B+ tree, the cost of searching {att} {op} {val} on {rel} is {total_pages_read} pages")
            else:
                print(f"Without B+ tree, the cost of searching {att} {op} {val} on {rel} is {total_pages_read} pages")
    else:
        print(f"Relation '{rel}' does not exist.")
# def select_records(rel, att, op, val):
#     array = []
#     pos = find_location_of_attr_in_tuple(rel, att)
#     cost = 0

#     relation_name = 'Select-' + rel + '-' + att
#     if os.path.isdir('../data/' + relation_name):
#         remove_table(relation_name)

#     find_tree_output = find_in_btree(rel, att, val)

#     if find_tree_output['btree']:
#         cost += find_tree_output['cost']
#         leaf = find_tree_output['leaf']
#         pages_array = []
#         for item in leaf['nodevalue']:
#             if item['key'] == val:
#                 pages_array = item['value']

#         for page in pages_array:
#             page_data = read_from_file("../data/" + rel + "/" + page)
#             cost += 1
#             for j in range(len(page_data)):
#                 tuples = page_data[j]
#                 value_for_comparison = tuples[pos]
#                 if op == '=':
#                     if value_for_comparison == val:
#                         array.append(tuples)
#                 elif op == '>=':
#                     if value_for_comparison >= val:
#                         array.append(tuples)
#                 elif op == '<=':
#                     if value_for_comparison <= val:
#                         array.append(tuples)
#                 elif op == '<':
#                     if value_for_comparison < val:
#                         array.append(tuples)
#                 elif op == '>':
#                     if value_for_comparison > val:
#                         array.append(tuples)

#         print("With B+_tree, the cost of searching " + att + " " +
#               op + " " + str(val) + " on " + rel + " is " + str(cost) + "  pages")
#     else:
#         page_link = "../data/" + rel + "/pageLink.txt"
#         page_array = read_from_file(page_link)
#         for i in range(len(page_array)):
#             page_data = read_from_file("../data/" + rel + "/" + page_array[i])
#             cost += 1
#             for j in range(len(page_data)):
#                 tuples = page_data[j]
#                 value_for_comparison = tuples[pos]
#                 if op == '=':
#                     if value_for_comparison == val:
#                         array.append(tuples)
#                 elif op == '>=':
#                     if value_for_comparison >= val:
#                         array.append(tuples)
#                 elif op == '<=':
#                     if value_for_comparison <= val:
#                         array.append(tuples)
#                 elif op == '<':
#                     if value_for_comparison < val:
#                         array.append(tuples)
#                 elif op == '>':
#                     if value_for_comparison > val:
#                         array.append(tuples)

#         print("Without B+_tree the cost of searching '" + att +
#               " " + op + " " + str(val) + "' on " + rel + " is " + str(cost) + " pages")

#     if not os.path.isdir('../data/' + relation_name):
#         os.mkdir('../data/' + relation_name)

#     page_link = []
#     for x in range(0, len(array), 2):
#         page_pool = read_from_file("../data/pagePool.txt")
#         l_page = page_pool.pop()
#         write_to_file(page_pool, "../data/pagePool.txt")
#         temp_file = []
#         temp_file.append(array[x])
#         if x + 1 < len(array):
#             temp_file.append(array[x + 1])
#         write_to_file(temp_file, "../data/" + relation_name + "/" + l_page)
#         page_link.append(l_page)

#     write_to_file(page_link, "../data/" + relation_name + "/pageLink.txt")

#     schema = read_from_file("../data/schemas.txt")
#     if schema:
#         for item in schema:
#             if item[0] == rel:
#                 schema_item = []
#                 schema_item.append(relation_name)
#                 schema_item.append(item[1])
#                 schema_item.append(item[2])
#                 schema_item.append(item[3])
#                 schema.append(schema_item)
#                 write_to_file(schema, "../data/schemas.txt")

#     return relation_name


def project_attributes(rel, att_list):
    pos_array = []
    for item in att_list:
        pos_array.append(find_location_of_attr_in_tuple(rel, item))
    path = "../data/" + rel + "/tmp"
    cost = 0

    relation_name = 'Projection'
    for att in att_list:
        relation_name = relation_name + '-' + att
    relation_name = relation_name + '-' + rel

    if os.path.isdir('../data/' + relation_name):
        remove_table(relation_name)

    if len(pos_array) == len(att_list):
        os.mkdir(path)
    else:
        return

    page_link = "../data/" + rel + "/pageLink.txt"
    page_array = read_from_file(page_link)
    temp_file_data = []
    for i in range(len(page_array)):
        page_data = read_from_file("../data/" + rel + "/" + page_array[i])
        cost += 1
        for j in range(len(page_data)):
            tuples = page_data[j]
            value_for_temp = []
            for k in range(len(pos_array)):
                value_for_temp.append(tuples[pos_array[k]])
            temp_file_data.append(value_for_temp)

    temp_all = []
    temp_all_pages = []
    for x in range(0, len(temp_file_data), 2):
        page_pool = read_from_file("../data/pagePool.txt")
        l_page = page_pool.pop()
        write_to_file(page_pool, "../data/pagePool.txt")
        cost += 1
        temp_file = []
        temp_file.append(temp_file_data[x])
        if x + 1 < len(temp_file_data):
            temp_file.append(temp_file_data[x + 1])
        write_to_file(temp_file, "../data/" + rel + "/tmp/" + l_page)
        temp_all_pages.append(l_page)
        temp_all.append(temp_file)

    write_to_file(temp_all_pages, "../data/" + rel + "/tmp/pageLink.txt")

    result_array = []
    for a in range(len(temp_all_pages)):
        item = read_from_file("../data/" + rel + "/tmp/" + temp_all_pages[a])
        for x in range(len(item)):
            if x + 1 < len(item) and item[x] == item[x + 1]:
                item.remove(item[x + 1])
        cost += 1
        for b in range(a + 1, len(temp_all_pages)):
            next_item = read_from_file("../data/" + rel + "/tmp/" + temp_all_pages[b])
            cost += 1
            for elem in item:
                for next_elem in next_item:
                    if elem == next_elem:
                        item.remove(next_elem)
        write_to_file(item, "../data/" + rel + "/tmp/" + temp_all_pages[a])
        result_array.append(item)

    result_items = []
    for item in result_array:
        result_items = result_items + item

    if not os.path.isdir('../data/' + relation_name):
        os.mkdir('../data/' + relation_name)

    page_link = []
    for x in range(0, len(result_items), 2):
        page_pool = read_from_file("../data/pagePool.txt")
        l_page = page_pool.pop()
        write_to_file(page_pool, "../data/pagePool.txt")
        temp_file = []
        temp_file.append(result_items[x])
        if x + 1 < len(result_items):
            temp_file.append(result_items[x + 1])
        write_to_file(temp_file, "../data/" + relation_name + "/" + l_page)
        page_link.append(l_page)

    write_to_file(page_link, "../data/" + relation_name + "/pageLink.txt")

    schema = read_from_file("../data/schemas.txt")
    if schema:
        for item in schema:
            if item[0] == rel:
                schema_item = []
                if item[1] in att_list:
                    schema_item.append(relation_name)
                    schema_item.append(item[1])
                    schema_item.append(item[2])
                    schema_item.append(item[3])
                    schema.append(schema_item)

    write_to_file(schema, "../data/schemas.txt")

    page_link = read_from_file("../data/" + rel + "/tmp/pageLink.txt")

    page_pool = read_from_file("../data/pagePool.txt")
    for page_no in page_link:
        os.remove("../data/" + rel + "/tmp/" + page_no)
        page_pool.append(page_no)

    write_to_file(page_pool, "../data/pagePool.txt")
    os.remove("../data/" + rel + "/tmp/pageLink.txt")
    os.rmdir("../data/" + rel + "/tmp")

    return relation_name


def join_relations(rel1, att1, rel2, att2):
    result_array = []
    pos_att1 = find_location_of_attr_in_tuple(rel1, att1)
    pos_att2 = find_location_of_attr_in_tuple(rel2, att2)
    cost = 0
    outer_rel = rel1
    inner_rel = rel2
    inner_att = att2
    outer_att = att1
    outer_rel_pos = pos_att1
    inner_rel_pos = pos_att2
    btree_available = False
    btree_on = ''

    root_rel1 = check_btree_on_rel_and_att(rel1, att1)
    if root_rel1 == '':
        root_rel2 = check_btree_on_rel_and_att(rel2, att2)
        if root_rel2 != '':
            btree_available = True
            inner_rel = rel2
            inner_rel_pos = pos_att2
            outer_rel = rel1
            outer_rel_pos = pos_att1
            inner_att = att2
            outer_att = att1
    else:
        btree_available = True
        inner_rel = rel1
        inner_rel_pos = pos_att1
        outer_rel = rel2
        outer_rel_pos = pos_att2
        inner_att = att1
        outer_att = att2

    relation_name = 'Join-' + outer_rel + '-' + inner_rel
    if os.path.isdir('../data/' + relation_name):
        remove_table(relation_name)
        print('deleting the existing directory' +
              relation_name + 'and free the page pool')

    if btree_available:
        pagelink_rel = "../data/" + outer_rel + "/pageLink.txt"
        page_array_rel = read_from_file(pagelink_rel)
        pagelink_rel_inner = "../data/" + inner_rel + "/pageLink.txt"
        page_array_rel_inner = read_from_file(pagelink_rel_inner)

        for page_rel in page_array_rel:
            page_data_rel = read_from_file("../data/" + outer_rel + "/" + page_rel)
            cost += 1
            for tuple_outer in page_data_rel:
                value_rel_outer = tuple_outer[outer_rel_pos]
                find_tree_output = find_in_btree(inner_rel, inner_att, value_rel_outer)
                cost += find_tree_output['cost']
                leaf = find_tree_output['leaf']
                pages_array = []
                for item in leaf['nodevalue']:
                    if item['key'] == value_rel_outer:
                        pages_array = item['value']

                if len(pages_array) > 0:
                    for page in pages_array:
                        page_data_inner = read_from_file("../data/" + inner_rel + "/" + page)
                        cost += 1
                        for tuple_inner in page_data_inner:
                            value_for_com = tuple_inner[inner_rel_pos]
                            if value_rel_outer == value_for_com:
                                result_item = []
                                for val in tuple_outer:
                                    result_item.append(val)
                                for x in range(len(tuple_inner)):
                                    if x != int(inner_rel_pos):
                                        result_item.append(tuple_inner[x])
                                result_array.append(result_item)

        print('Cost of Joining ' + rel1 + ' and ' + rel2 +
              ' with B+ tree on ' + inner_rel + ' is ' + str(cost) + ' I/Os')
    else:
        pagelink_rel1 = "../data/" + outer_rel + "/pageLink.txt"
        page_array_rel1 = read_from_file(pagelink_rel1)
        pagelink_rel2 = "../data/" + inner_rel + "/pageLink.txt"
        page_array_rel2 = read_from_file(pagelink_rel2)
        for page_rel1 in page_array_rel1:
            page_data_rel1 = read_from_file("../data/" + outer_rel + "/" + page_rel1)
            cost += 1
            for page_rel2 in page_array_rel2:
                page_data_rel2 = read_from_file("../data/" + inner_rel + "/" + page_rel2)
                cost += 1
                for tuple_rel1 in page_data_rel1:
                    value_rel1 = tuple_rel1[pos_att1]
                    for tuple_rel2 in page_data_rel2:
                        value_rel2 = tuple_rel2[pos_att2]
                        if value_rel1 == value_rel2:
                            result_item = []
                            for val in tuple_rel1:
                                result_item.append(val)
                            for x in range(len(tuple_rel2)):
                                if x != int(inner_rel_pos):
                                    result_item.append(tuple_rel2[x])
                            result_array.append(result_item)

        print('Cost of Joining ' + rel1 + ' and ' + rel2 +
              ' without B+ tree is ' + str(cost) + ' I/Os')

    if not os.path.isdir('../data/' + relation_name):
        os.mkdir('../data/' + relation_name)

    schema = read_from_file("../data/schemas.txt")
    if schema:
        position = 0
        for item in schema:
            if item[0] == outer_rel:
                schema_item = []
                schema_item.append(relation_name)
                schema_item.append(item[1])
                schema_item.append(item[2])
                schema_item.append(position)
                position += 1
                schema.append(schema_item)

        for item in schema:
            if item[0] == inner_rel:
                if item[1] != inner_att:
                    schema_item = []
                    schema_item.append(relation_name)
                    schema_item.append(item[1])
                    schema_item.append(item[2])
                    schema_item.append(position)
                    position += 1
                    schema.append(schema_item)

    write_to_file(schema, "../data/schemas.txt")

    page_link = []
    for x in range(0, len(result_array), 2):
        page_pool = read_from_file("../data/pagePool.txt")
        l_page = page_pool.pop()
        write_to_file(page_pool, "../data/pagePool.txt")
        # cost += 1
        temp_file = []
        temp_file.append(result_array[x])
        if x + 1 < len(result_array):
            temp_file.append(result_array[x + 1])
        write_to_file(temp_file, "../data/" + relation_name + "/" + l_page)
        page_link.append(l_page)

    write_to_file(page_link, "../data/" + relation_name + "/pageLink.txt")

    return relation_name

       
