from buildTree import traverse_all_node , read_from_file as tree_read,  write_to_file as tree_write
import json

def display_tree(filename):
    if filename != '':
        all_items = traverse_all_node(filename)
        seen_pages = set()
        new_list = []
        for obj in all_items:
            if obj['page'] not in seen_pages:
                new_list.append(obj)
                seen_pages.add(obj['page'])

        directory = tree_read("../index/directory.txt")
        tree_item = ''
        for item in directory:
            if item[2] == filename:
                tree_item = item

        if tree_item != '':
            tree_file = open("../treePic/" + tree_item[0] + "_" + tree_item[1] + ".txt", "w")
            for item in new_list:
                if item['type'] == 'I' and item['parent'] != '':
                    tree_file.write('\t')
                if item['type'] == 'L':
                    tree_file.write('\t')
                    tree_file.write('\t')
                tree_file.write(str(item))
                tree_file.write('\n')
            tree_file.close()

def display_table(rel_name):
    if rel_name != '':
        page_link = "../data/" + rel_name + "/pageLink.txt"
        page_array = tree_read(page_link)

        results = []
        for pages in page_array:
            page_item = tree_read("../data/" + rel_name + "/" + pages)
            results.append(page_item)

        query_output = "../queryOutput/queryResult.txt"
        with open(query_output, 'a') as f:
            f.write('\n')
            for item in results:
                json.dump(item, f)
                f.write("\n")
            f.write("\n\n\n")
            f.write("------------------------------------------------------------")
            f.write("\n")

# display_tree('pg30.txt')
