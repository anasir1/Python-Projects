from remove import remove_tree, remove_table
from relAlg import project_attributes as project, select as select, join_relations as join
from buildTree import build_btree as build
from display import display_table, display_tree
import json
import os

output_question = 'Projection-sname-Select-Suppliers-sid'
select_output_question = 'Select-Suppliers-sid'


def read_json(path):
    try:
        file = open(path)
        return json.load(file)
    except:
        return


def main():
    while True:
        user_choice = input(
            "\n\nEnter the question (number) you want to call: \n " +
            "1. Find the name for the supplier 's23' when a B+_tree exists on Suppliers.sid \n " +
            "2. Remove the name for the supplier 's23' when a B+_tree does not exist \n " +
            "3. Find the address of the suppliers who supplied 'p15'. \n " +
            "4. What is the cost of 'p20' supplied by 'Kiddie'? \n " +
            "5. For each supplier who supplied products with a cost of 47 or higher, list his/her name, product name, and cost. \n " +
            "0. Exit \n " +
            "Enter Number: ")

        if user_choice == '1':
            choice_1()

        elif user_choice == '2':
            choice_2()

        elif user_choice == '3':
            choice_3()

        elif user_choice == '4':
            choice_4()

        elif user_choice == '5':
            choice_5()
        else:
            print('Terminating the process...')
            break


def choice_1():
    # Find the name for the supplier ‘s23’ when a B+_tree exists on Suppliers.sid
    output = select('Suppliers', 'sid', '=', 's23')
    display_table(output)

    return


def choice_2():
    # Remove the name for the supplier "s23" repeat question 1

    remove_tree('Suppliers', 'sid')

    supplier_value = 's23'
    relation = 'Suppliers'
    output_attribute_list = ['sname']

    selecting_relation_name = select(relation, 'sid', '=', supplier_value)

    output_related = project(selecting_relation_name, output_attribute_list)

    display_table(output_related)

    return


def choice_3():
    # Find the address of the suppliers who supplied 'p15'.

    build('Suppliers', 'sid', 2)
    build('Supply', 'pid', 2)

    select_output_related = select('Supply', 'pid', '=', 'p15')

    join_rel_name = join(select_output_related, 'sid', 'Suppliers', 'sid')

    output_related = project(join_rel_name, ['address'])

    display_table(output_related)

    return


def choice_4():
    # What is the cost of 'p20' supplied by 'Kiddie'?

    select_supply_output = select('Supply', 'pid', '=', 'p20')

    select_suppliers_output = select('Suppliers', 'sname', '=', 'Kiddie')

    join_result = join(select_supply_output, 'sid', select_suppliers_output, 'sid')

    project_result = project(join_result, ['cost'])

    display_table(project_result)

    return


def choice_5():

    # For each supplier who supplied products with a cost of 47 or higher, list his/her name, product name, and the cost.

    select_cost_supply = select('Supply', 'cost', '>=', 47)

    join_result = join('Suppliers', 'sid', select_cost_supply, 'sid')

    double_join_result = join('Products', 'pid', join_result, 'pid')

    output_result = project(double_join_result, ['sname', 'pname', 'cost'])

    display_table(output_result)

    return


def display_both_trees():
    directory = read_json("../index/directory.txt")
    root_page = ''
    for item in directory:
        root_page = item[2]
        display_tree(root_page)

    return


def remove_all_extra_tables():
    path = '../data/'

    directory_contents = os.listdir(path)
    # print(directory_contents)
    for item in directory_contents:
        if os.path.isdir(path + item):
            if item != 'Suppliers' and item != 'Supply' and item != 'Products':
                remove_table(item)

main()