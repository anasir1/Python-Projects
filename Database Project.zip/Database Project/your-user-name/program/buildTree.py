import json

current_relation = ''
current_order = 1
current_attribute = ''

def read_from_file(path):
    with open(path) as file:
        return json.load(file)

def write_to_file(text, page):
    with open(page, 'w') as f:
        json.dump(text, f)


def find_location_of_attribute_in_tuple(rel, att):
    schema = read_from_file("../data/schemas.txt")
    for item in schema:
        if item[0] == str.capitalize(rel) and item[1] == att:
            return item[3]

def check_btree_on_rel_and_att(rel, att):
    directory = read_from_file("../index/directory.txt")
    root_page = ''  
    for item in directory:
        if item[0] == rel and item[1] == att:
            root_page = item[2]
    return root_page

def build_btree(rel, att, odd):
    if check_btree_on_rel_and_att(rel, att) != '':
        print('B+ tree on <' + rel + ',' + att + '> already exists')
        return 

    global current_relation
    current_relation = rel
    global current_order
    current_order = odd
    global current_attribute
    current_attribute = att
    page_link = "../data/" + rel + "/pageLink.txt"
    page_array = read_from_file(page_link)

    pos = find_location_of_attribute_in_tuple(rel, att)

    for i in range(len(page_array)):
        page = read_from_file('../data/' + rel + '/' + page_array[i])

        for j in range(len(page)):
            sk = page[j][pos]
            sk_val = page_array[i]
            leaf_node_return = find_in_tree(rel, att, sk)
            leaf_node = leaf_node_return['page']

            if leaf_node == '':
                node_item = {}
                node_item['key'] = sk
                node_item['value'] = [sk_val]
                new_page = create_leaf_node([node_item], '', {'left': '', 'right': ''}, odd)
                directory_main = read_from_file("../index/directory.txt")
                directory_main.append([rel, att, new_page])
                write_to_file(directory_main, "../index/directory.txt")
            else:
                leaf_node_data = read_from_file("../index/" + leaf_node['page'])
                new_leaf = insert_in_leaf_node(leaf_node_data, sk, sk_val)

                if len(new_leaf['nodevalue']) > (2 * odd):
                    split_the_leaf(new_leaf, odd, rel)
                else:
                    write_to_file(new_leaf, "../index/" + new_leaf['page'])

    return

def traverse_all_node(root_page):
    result_array = []
    root = read_from_file("../index/" + root_page)
    if root['type'] == 'L':
        result_array.append(root)
        return result_array
    else:
        result_array.append(root)
        for item in root['nodevalue']:
            left_array = traverse_all_node(item['leftNode'])
            result_array = result_array + left_array
            right_array = traverse_all_node(item['rightNode'])
            result_array = result_array + right_array
        return result_array

def traverse_in_tree(page_no, sk, traverse_cost):
    page = read_from_file("../index/" + page_no)
    traverse_cost = traverse_cost + 1
    if page['type'] == 'L':
        return {'page': page, 'cost': traverse_cost}
    else:
        all_val = page['nodevalue']
        for i in range(len(all_val)):
            if sk < all_val[i]['key']:
                return traverse_in_tree(all_val[i]['leftNode'], sk, traverse_cost)
            elif (sk >= all_val[i]['key'] and i == len(all_val) - 1) or (sk >= all_val[i]['key'] and sk < all_val[i + 1]['key']):
                return traverse_in_tree(all_val[i]['rightNode'], sk, traverse_cost)

def find_in_tree(rel, att, sk):
    directory = read_from_file("../index/directory.txt")
    root_page = ''
    traverse_cost = 0
    for item in directory:
        if item[0] == rel and item[1] == att:
            root_page = item[2]
    if root_page != '':
        result = traverse_in_tree(root_page, sk, traverse_cost)
        return {'page': result['page'], 'cost': result['cost']}
    else:
        return {"page": root_page, "cost": traverse_cost}

def is_key_in_node(node, sk):
    for node_item in node['nodevalue']:
        if node_item['key'] == sk:
            return True
    return False

def insert_in_leaf_node(leaf_node_data, sk, sk_val):
    node = leaf_node_data
    if is_key_in_node(node, sk):
        # append value in the array where key = sk
        for node_item in node['nodevalue']:
            if node_item['key'] == sk:
                node_item['value'].append(sk_val)
    else:
        # insert in node
        temp_node = {}
        temp_node['key'] = sk
        temp_node['value'] = [sk_val]
        node['nodevalue'].append(temp_node)
        node['nodevalue'].sort(key=lambda x: x['key'])
    return node

def insert_in_internal_node(internal_node, node_item, left_node, right_node, odd, rel):
    node = internal_node
    # sort the nodevalue
    node['nodevalue'].append(node_item)
    node['nodevalue'].sort(key=lambda x: x['key'])
    left_leaf = read_from_file('../index/' + left_node)
    left_leaf['parent'] = node['page']
    write_to_file(left_leaf, '../index/' + left_node)
    right_leaf = read_from_file('../index/' + right_node)
    right_leaf['parent'] = node['page']
    write_to_file(right_leaf, '../index/' + right_node)

    if len(node['nodevalue']) > (2 * odd):
        # split the internal node
        source_list = node['nodevalue']
        N = odd
        new_left_list = []
        for index in range(0, N):
            new_left_list.append(source_list[index])
        new_right_list = []
        for index in range(N + 1, len(node['nodevalue'])):
            new_right_list.append(source_list[index])

        parent = node['parent']

        left_internal = {}
        left_internal['parent'] = parent
        left_internal['page'] = node['page']
        left_internal['type'] = 'I'
        left_internal['nodevalue'] = new_left_list

        write_to_file(left_internal, "../index/" + node['page'])

        new_page = create_internal_node(new_right_list, parent, odd)

        copy_to_parent(source_list[N]['key'], parent, node['page'], new_page, rel, odd)
    else:
        write_to_file(node, "../index/" + node['page'])

    return node

def create_leaf_node(leaf_items, parent, siblings, odd):
    page_pool = read_from_file("../index/pagePool.txt")
    l_page = page_pool.pop()
    write_to_file(page_pool, "../index/pagePool.txt")
    node_p = {}
    node_p['page'] = l_page
    node_p['parent'] = parent
    node_p['type'] = 'L'
    node_p['nodevalue'] = []
    if siblings:
        node_p['leftSibiling'] = siblings['left']
        node_p['rightSibiling'] = siblings['right']
    else:
        node_p['leftSibiling'] = ''
        node_p['rightSibiling'] = ''

    for item in leaf_items:
        node = {}
        node['key'] = item['key']
        node['value'] = item['value']
        node_p['nodevalue'].append(node)

    write_to_file(node_p, "../index/" + l_page)
    return l_page

def create_internal_node(node_items, parent, odd):
    page_pool = read_from_file("../index/pagePool.txt")
    l_page = page_pool.pop()
    write_to_file(page_pool, "../index/pagePool.txt")
    node_p = {}
    node_p['page'] = l_page
    node_p['parent'] = parent
    node_p['type'] = 'I'
    node_p['nodevalue'] = []

    for item in node_items:
        node = {}
        node['leftNode'] = item['leftNode']
        # change the parent of the leaf nodes
        left_node = read_from_file("../index/" + item['leftNode'])
        left_node['parent'] = l_page
        write_to_file(left_node, "../index/" + item['leftNode'])
        node['rightNode'] = item['rightNode']
        right_node = read_from_file("../index/" + item['rightNode'])
        right_node['parent'] = l_page
        write_to_file(right_node, "../index/" + item['rightNode'])
        node['key'] = item['key']
        node_p['nodevalue'].append(node)

    write_to_file(node_p, "../index/" + l_page)
    return l_page

def split_the_leaf(leaf_node, odd, rel):

    source_list = leaf_node['nodevalue']
    N = odd
    new_left_list = []
    for index in range(0, N):
        new_left_list.append(source_list[index])
    new_right_list = []
    for index in range(N, len(leaf_node['nodevalue'])):
        new_right_list.append(source_list[index])
    
    parent = leaf_node['parent']

    left_leaf = {}
    left_leaf['page'] = leaf_node['page']
    left_leaf['parent'] = leaf_node['parent']
    left_leaf['type'] = 'L'
    left_leaf['nodevalue'] = new_left_list
    left_leaf['leftSibiling'] = leaf_node['leftSibiling']
    
    new_page = create_leaf_node(new_right_list, parent, {'left': left_leaf['page'], 'right': ''}, odd)
    
    left_leaf['rightSibiling'] = new_page
    write_to_file(left_leaf, "../index/" + left_leaf['page'])

    copy_elem = new_right_list[0]['key']

    copy_to_parent(copy_elem, parent, left_leaf['page'], new_page, rel, odd)
    return

def copy_to_parent(elem, parent, ln, rn, rel, odd):
    if parent == "":
        node_item = {}
        node_item['key'] = elem
        node_item['leftNode'] = ln
        node_item['rightNode'] = rn
        parent_page = create_internal_node([node_item], parent, odd)
        left_leaf = read_from_file('../index/' + ln)
        left_leaf['parent'] = parent_page
        write_to_file(left_leaf, '../index/' + ln)
        right_leaf = read_from_file('../index/' + rn)
        right_leaf['parent'] = parent_page
        write_to_file(right_leaf, '../index/' + rn)

        directory_elem = read_from_file("../index/directory.txt")
        for item in directory_elem:
            if item[0] == current_relation and item[1] == current_attribute:
                item[2] = parent_page
        write_to_file(directory_elem, "../index/directory.txt")
        # change the root page in the directory
    else:
        internal_node = read_from_file('../index/' + parent)
        node_item = {}
        node_item['key'] = elem
        node_item['leftNode'] = ln
        node_item['rightNode'] = rn
        insert_in_internal_node(internal_node, node_item, ln, rn, odd, rel)
    return

def traverse_all_node(root_page):
    result_array = []
    root = read_from_file("../index/" + root_page)
    if root['type'] == 'L':
        # print(root)
        result_array.append(root)
        return result_array
    else:
        result_array.append(root)
        # result_array = result_array +  append(root)
        for item in root['nodevalue']:
            left_array = traverse_all_node(item['leftNode'])
            result_array = result_array + left_array
            # result_array.append(traverse_all_node(item['leftNode']))
            right_array = traverse_all_node(item['rightNode'])
            result_array = result_array + right_array
            # result_array.append(traverse_all_node(item['rightNode']))
        return result_array

# build('Supply', 'pid', 2)
